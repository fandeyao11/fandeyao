export interface ParallaxMethods {}

export interface ParallaxEvents {}
