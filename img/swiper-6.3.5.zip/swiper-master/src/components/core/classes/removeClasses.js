export default function removeClasses() {
  const swiper = this;
  const { $el, classNames } = swiper;

  $el.removeClass(classNames.join(' '));
  swiper.emitContainerClasses();
}
